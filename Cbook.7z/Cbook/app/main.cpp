#include "../inc/hello.h"
#include<iostream>

struct STUDENT
{
    char name[20];
    float score;
};

void InputStudent(int cnt, STUDENT *p);
void ScoreRating(int cnt, STUDENT *p);
void OutputStudent(int cnt, const STUDENT *p);

int main(void)
{   
    Hello();

    int cnt;
    puts("������ѧ����������cnt = ");
    scanf("%d",&cnt);
    getchar();

    STUDENT *p = (STUDENT *)malloc(cnt * sizeof(*p));

    InputStudent(cnt, p);
    ScoreRating(cnt, p);
    OutputStudent(cnt,p);

    free(p);
    p = NULL;
    
    return 0;
}

void InputStudent(int cnt, STUDENT *p)
{
    int i;
    for (i=0; i<cnt; i++)
    {
        printf("�������%d��ѧ������Ϣ��\n", i+1);

        printf("������");
        scanf("%s", (p+i)->name);
        getchar();

        printf("������");
        scanf("%f", &(p+i)->score);
        getchar();
    }
    printf("\n");

    return;
}

void ScoreRating(int cnt, STUDENT *p)
{
    int i,j;
    STUDENT temp;

    for (i=0; i<cnt-1;i++)
    {
        for (j=0; j<cnt-1-i; j++)
        {
            if ((p+j)->score < (p+j+1)->score)
            {
                temp = *(p+j);
                *(p+j) = *(p+j+1);
                *(p+j+1) = temp;
            }
            else
            {
                ;
            }
        }
    }

    return;
}

void OutputStudent(int cnt, const STUDENT *p)
{
    int i;

    puts("���ɼ�˳������:");

    for (i=0; i<cnt; i++)
    {
        printf("ranking: %d\tname: %s\tscore: %.1f\n", i+1, (p+i)->name, (p+i)->score);
    }

    return;
}