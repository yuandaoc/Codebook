# ifndef _HELLO_H_
# define _HELLO_H_
int Hello(void);
int Min(void);
int Reverse(void);
int LinearSearch(void);
int BinarySearch(void);
int BubbleSort(int *a, int sizeofarray);
int InsertSort(int *a, int sizeofarray);
int SelectSort(int *a, int sizeofarray);
void QuickSort(int *a, int low, int high);
long Factorial(int n);
int Sum(int n);
void Swap(int *p, int *q);
# endif